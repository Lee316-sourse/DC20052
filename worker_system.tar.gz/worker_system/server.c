/*================================================================
*   Copyright (C) 2020 hqyj Ltd. All rights reserved.
*   
*   文件名称：server.c
*   创 建 者：Lee
*   创建日期：2020年10月11日
*   描    述：
*
================================================================*/


#include "head.h"


int main(int argc, char *argv[])
{
	sqlite3* db;

	cli_info* cli = malloc(sizeof(cli_info));
	struct sockaddr_in sin;
	socklen_t sin_addrlen = sizeof(sin);
	struct sockaddr_in cin;
	socklen_t cin_addrlen = sizeof(cin);
	pthread_t tid;
	int acceptfd = -1;
/*----------------------------创建数据库-----------------------------*/
	database_create(db,cli);

/*-------------------------服务器初始化模块--------------------------*/
	int fd = socket(AF_INET,SOCK_STREAM,0);
	if(fd == -1){
		perror("socket");
		exit(1);
	}

	//允许地址重用
	int flag = 1;
	setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&flag,sizeof(flag));
	
	//1 填充本地地址信息结构体
	sin.sin_family = AF_INET;
	sin.sin_port   = htons(SERV_PORT);
	if(inet_pton(AF_INET,"0.0.0.0",&sin.sin_addr.s_addr)<0){
		perror("pton");
		exit(1);
	}
	
	//2 bind
	if(bind(fd,(struct sockaddr*)&sin,sin_addrlen)<0){
		perror("bind");
		exit(1);
	}

	//3 listen
	if(listen(fd,BACKLOG)<0){
		perror("listen");
		exit(1);
	}
	puts("服务器就绪");
/*----------------------------收发消息-----------------------------*/
	while(1){
		//4 accpet
		if((acceptfd = accept(fd,(struct sockaddr*)&cin,&cin_addrlen))<0){
			perror("accept");
			break;
		}
		//打印客户端信息
		client_info(cin);
		cli->cin = cin;
		cli->newfd = acceptfd;
		//创建线程
		pthread_create(&tid,NULL,(void*)client_handle,cli);
	}
	close(fd);
	return 0;
}

/*-----------------------打印客户端连接信息------------------------*/
void client_info(const struct sockaddr_in cin)
{
	char ip_buf[25] = {};
	if(inet_ntop(AF_INET,&cin.sin_addr.s_addr,ip_buf,sizeof(ip_buf))==NULL){
		perror("ntop");
		exit(1);
	}
	printf("IP:%s 端口号:%d  链接成功\n",ip_buf,ntohs(SERV_PORT));
}

/*--------------------------线程处理函数----------------------------*/
void client_handle(cli_info* arg)
{
	
	
	MSG M;
	int a;
	int ret = -1;
	pthread_detach(pthread_self());	//线程分离
	int newfd = arg->newfd;
	
	while(1){

		bzero(&M,sizeof(M));
		ret = recv(newfd,&M,sizeof(MSG),0);
					
			if(ret<0){
			perror("recv");
			exit(1);
		}else if(0 == ret){
			printf("客户端:%s fd:%d已关闭\n",inet_ntoa(arg->cin.sin_addr),newfd);
			break;
		}else{
//			printf("收到IP:%s fd:%d 数据: name:%s pass:%s\n",
//					inet_ntoa(arg->cin.sin_addr),
//				newfd,M.cl.name,M.cl.password);
			switch(M.cmd){
				case REGISTER://注册账户
					database_insert(arg->newdb, arg->errmsg, &M);
					break;
				case LOGIN://登录账户
					database_strcmp(arg->newfd, arg->newdb, arg->errmsg, &M);
					break;
				case 3:	//添加人员
					database_add(arg->newfd, arg->newdb, arg->errmsg, &M);
					break;
				case 4://查找人员
					database_find(arg->newfd, arg->newdb, arg->errmsg, &M);
					break;
				case 5://删除人员
					database_del(arg->newfd, arg->newdb, arg->errmsg, &M);
					break;
				case 6:
					database_change(arg->newfd, arg->newdb, arg->errmsg, &M);
					break;
				default:
					puts("输入有误");
					break;
			}
		}

	}
	close(newfd);
	pthread_exit(NULL);
}

/*------------------------------数据库创建函数-----------------------------*/
void database_create(sqlite3* db, cli_info* cli)
{
	//创建数据库
	if(sqlite3_open("./client.db",&db)!=0){
		printf("sqlite_open:%s\n",sqlite3_errmsg(db));
		exit(-1);
	}
	
	//创建账号密码表格
	char* create_table = "create table if not exists client(name char,password char)";
	if(sqlite3_exec(db,create_table,NULL,NULL,&cli->errmsg)!=0){
		printf("create_table1:%s\n",sqlite3_errmsg(db));
		exit(-1);
	}
		
	//创建员工信息表格
	char* create_table1 = "create table if not exists worker_info(part char, name char, numb char,\
							sex char, age int, salary float, tele int, addr char)";
	if(sqlite3_exec(db,create_table1,NULL,NULL,&cli->errmsg)!=0){
		printf("create_table2:%s\n",sqlite3_errmsg(db));
		exit(1);
	}

	cli->newdb = db;

}

/*-------------------------添加注册账户信息到数据库------------------------*/
void database_insert(sqlite3* db, char* errmsg, MSG* msg)
{
	char sq[100]={};
	
	sprintf(sq,"insert into client values('%s','%s')",
			msg->cl.name,msg->cl.password);
	printf("%s\n",sq);
	if(sqlite3_exec(db,sq,NULL,NULL,&errmsg)!=0){
		printf("insert:%s\n",sqlite3_errmsg(db));
		exit(1);
	}
}

/*-----------------------查找数据库中登录账户信息--------------------------*/
void database_strcmp(int fd, sqlite3* db, char* errmsg, MSG* msg)
{
	int ret= -1;
	char sql[100] = {};
	int nrow;
	int ncloumn;
	char** resultp;
	
	sprintf(sql,"select * from client where name = '%s' and password = '%s';",
			msg->cl.name,msg->cl.password);
	printf("%s\n",sql);

	if(sqlite3_get_table(db,sql,&resultp,&nrow,&ncloumn,&errmsg)!=0){
		printf("get_table:%s\n",errmsg);
		exit(1);
	}else
//	puts("查询成功");

	//查询成功，数据库有此用户.
	if(nrow == 1){
		strcpy(msg->cl.result,"OK");
		ret = send(fd,msg,sizeof(MSG),0);
		if(ret <0){
			perror("register_send1");
			exit(1);
		}
		if(0 == ret){
			puts("客户端关闭");
		}
	}
	if(nrow == 0){
		strcpy(msg->cl.result,"usr/password wrong");
		ret = send(fd,msg,sizeof(MSG),0);
		if(ret <0){
			perror("register_send2");
			exit(1);
		}
		if(0 == ret){
			puts("客户端关闭");
		}
	}
}

/*------------------------添加人员信息到数据库-----------------------------*/
void database_add(int fd, sqlite3* db, char* errmsg, MSG* msg)
{
	int ret = -1;
	char sql[300] = {};
	sprintf(sql,"insert into worker_info values('%s','%s','%s','%s','%d','%f','%s','%s');",\
			msg->info.part,msg->info.name,msg->info.numb,msg->info.sex,msg->info.age,\
			msg->info.salary,msg->info.tele,msg->info.addr);
	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0){
		printf("database_add:%s\n",errmsg);
		exit(1);
	}else{
		//添加人员信息成功
		strcpy(msg->info.result,"OK");
		ret = send(fd,msg,sizeof(MSG),0);
		if(ret <0){
			perror("database_add_send");
			bzero(msg,sizeof(MSG));
			exit(1);
		}
		if(0 == ret){
			puts("客户端关闭");
		}

	}
}
/*------------------------查询数据库人员信息-----------------------------*/
void database_find(int fd, sqlite3* db, char* errmsg, MSG* msg)
{
	int ret= -1;
	int nrow;
	int ncloumn;
	char** resultp;
	char sql[100] = {};

//查询人员信息是否在数据库	
	sprintf(sql,"select * from worker_info where name = '%s' and numb = '%s';",
			msg->info.name,msg->info.numb);
	printf("%s\n",sql);
	if(sqlite3_get_table(db,sql,&resultp,&nrow,&ncloumn,&errmsg)!=0){
		printf("find_get_table:%s\n",errmsg);
		exit(1);
	}else{
		if(nrow > 0){
	//查询成功，数据库有此用户
			if(sqlite3_exec(db,sql,callback,&fd,&errmsg)!=0){
				printf("database_find:%s\n",sqlite3_errmsg(db));
				exit(1);
			}
		}
		if(nrow ==0){
			strcpy(msg->info.result,"find_error");
			ret = send(fd,msg,sizeof(MSG),0);
			if(ret <0){
				perror("find_gettable_send");
				exit(1);
			}
			if(0 == ret){
				puts("客户端关闭");
			
			}
		}
	}
}

int callback(void* para, int f_num, char** f_value,char** f_name)
{
	int ret = -1;
	int i=0;
	int fd = (int)(*(int*)(para));
	MSG M;
	
	sprintf(M.data_name,"%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s",
			f_name[0],f_name[1],f_name[2],f_name[3],f_name[4],
			f_name[5],f_name[6],f_name[7]);

	sprintf(M.data_value,"%-13s%-13s   %-13s%-13s %-13s%-13s%-13s%-13s",
			f_value[0],f_value[1],f_value[2],f_value[3],f_value[4],
			f_value[5],f_value[6],f_value[7]);

	ret = send(fd,&M,sizeof(M),0);
	if(ret <0){
		perror("callback_send");
		exit(1);
	}else if(0 == ret){
		puts("客户端已关闭");
		exit(1);
	}else{
		puts("发送查询数据成功");
	}

	return 0;
}

/*------------------------删除数据库人员信息-----------------------------*/
void database_del(int fd, sqlite3* db, char* errmsg,MSG* msg)
{
	char sql[150] = {};	
	char sq[150] = {};
	int nrow;
	int ncloumn;
	char** resultp;
	int ret = -1;

//先检查删除信息是否存在数据库	
	sprintf(sq,"select * from worker_info where name = '%s' and numb = '%s';",
			msg->info.name,msg->info.numb);
	printf("%s\n",sq);

	if(sqlite3_get_table(db,sq,&resultp,&nrow,&ncloumn,&errmsg)!=0){
		printf("find_get_table:%s\n",errmsg);
		exit(1);
	}else{
		if(nrow > 0){
	//查询成功，数据库有此用户.开始删除操作
			sprintf(sql,"delete from worker_info where name = '%s' and numb = '%s';",
					msg->info.name,msg->info.numb);
			printf("%s\n",sql);

			if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0){
				printf("database_del:%s\n",errmsg);
				exit(1);
			}else{
				//删除成功
				puts("删除成功");
				strcpy(msg->info.result,"OK");
				ret = send(fd,msg,sizeof(MSG),0);
				if(ret <0){
					perror("database_del_send");
					exit(1);
				}
				if(0 == ret){
					puts("客户端已关闭");
					exit(1);
				}
			}

		}

		if(nrow == 0){
	//查询不成功，数据库无该人员信息
			strcpy(msg->info.result,"error");
			ret = send(fd,msg,sizeof(MSG),0);
			if(ret <0){
				perror("del_gettable_send1");
				exit(1);
			}
			if(0 == ret){
				puts("客户端关闭");
			}
		}

	}
}

/*------------------------修改数据库人员信息-----------------------------*/
void database_change(int fd, sqlite3* db, char* errmsg, MSG* msg)
{
	char sql[250] = {};	
	char sq[250] = {};	
	int nrow;
	int ncloumn;
	char** resultp;
	int ret = -1;
//先检查删除信息是否存在数据库	
	sprintf(sq,"select * from worker_info where name = '%s' and numb = '%s';",
			msg->info.name,msg->info.numb);
	printf("%s\n",sq);

	if(sqlite3_get_table(db,sq,&resultp,&nrow,&ncloumn,&errmsg)!=0){
		printf("find_get_table:%s\n",errmsg);
		exit(1);
	}else{
		if(nrow > 0){
		//查询成功，数据库有此用户.开始修改操作
			switch(msg->info.cmd_info){
				case 1:
					sprintf(sql,"update worker_info set part = '%s' where name = '%s' and numb = '%s';",
							msg->info.part,msg->info.name,msg->info.numb);
					printf("%s\n",sql);
					
					if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0){
						printf("database_change_part:%s\n",errmsg);
						exit(1);
					}
					break;
				case 2:
					sprintf(sql,"update worker_info set name = '%s' where name = '%s' and numb = '%s';",
							msg->info.name,msg->info.name,msg->info.numb);
					printf("%s\n",sql);
					
					if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0){
						printf("database_change_name:%s\n",errmsg);
						exit(1);
					}

					break;
				case 3:
					sprintf(sql,"update worker_info set numb = '%s' where name = '%s' and numb = '%s';",
							msg->info.numb,msg->info.name,msg->info.numb);
					printf("%s\n",sql);

					if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0){
						printf("database_change_numb:%s\n",errmsg);
						exit(1);
					}
					break;
				case 4:
					sprintf(sql,"update worker_info set sex = '%s' where name = '%s' and numb = '%s';",
							msg->info.sex,msg->info.name,msg->info.numb);
					printf("%s\n",sql);

					if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0){
						printf("database_change_sex:%s\n",errmsg);
						exit(1);
					}
					break;
				case 5:
					sprintf(sql,"update worker_info set age = '%d' where name = '%s' and numb = '%s';",
							msg->info.age,msg->info.name,msg->info.numb);
					printf("%s\n",sql);

					if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0){
						printf("database_change_age:%s\n",errmsg);
						exit(1);
					}
					break;
				case 6:
					sprintf(sql,"update worker_info set salary = '%f' where name = '%s' and numb = '%s';",
							msg->info.salary,msg->info.name,msg->info.numb);
					printf("%s\n",sql);

					if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0){
						printf("database_change_salary:%s\n",errmsg);
						exit(1);
					}
					break;
				case 7:
					sprintf(sql,"update worker_info set tele = '%s' where name = '%s' and numb = '%s';",
							msg->info.tele,msg->info.name,msg->info.numb);
					printf("%s\n",sql);

					if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0){
						printf("database_change_tele:%s\n",errmsg);
						exit(1);
					}
					break;
				case 8:
					sprintf(sql,"update worker_info set addr = '%s' where name = '%s' and numb = '%s';",
							msg->info.addr,msg->info.name,msg->info.numb);
					printf("%s\n",sql);

					if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)!=0){
						printf("database_change_addr:%s\n",errmsg);
						exit(1);
					}
					break;
				default:
					puts("输入有误");
					break;
			}
		
			strcpy(msg->info.result,"change_ok");
			ret = send(fd,msg,sizeof(MSG),0);
			if(ret < 0){
				perror("database_change_send");
				exit(1);
			}else if(0 == ret){
				puts("客户端关闭");
			}else{
				puts("修改信息成功");
			}
		}
		if(0 == nrow){
		//查询不成功，数据库无该人员信息
			strcpy(msg->info.result,"change_error");
			
			ret = send(fd,msg,sizeof(MSG),0);
			if(ret < 0){
				perror("database_change_send");
				exit(1);
			}else if(0 == ret){
				puts("客户端关闭");
			}else{
				puts("修改信息成功");
			}

		}
	}
}
