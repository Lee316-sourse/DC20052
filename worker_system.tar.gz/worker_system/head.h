/*================================================================
*   Copyright (C) 2020 hqyj Ltd. All rights reserved.
*   
*   文件名称：head.h
*   创 建 者：Lee
*   创建日期：2020年10月11日
*   描    述：
*
================================================================*/


#ifndef HEAD_H__
#define HEAD_H__

#include <stdio.h>
#include <sqlite3.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>

#define SERV_PORT 6666
#define SERV_IP "192.168.2.179"
#define BACKLOG 25
#define ADMIN_NAME "Li_evarb"
#define ADMIN_PASSWORD "yy950316"


char buf_name[30];
char buf_numb[30];
/*----------------客户端信息结构体-------------------*/
typedef struct client_info{
	struct sockaddr_in cin;
	sqlite3* newdb;
	char* errmsg;
	int newfd;
	}cli_info;

/*----------------用户信息结构体---------------------*/
struct worker_info{
	int cmd_info;
	char result[20];
	char part[20];
	char name[20];
	char numb[20];
	char sex[10];
	int age;
	float salary;
	char tele[15];
	char addr[100];
};

/*----------------登录账户结构体---------------------*/
struct client{
	char result[20];
	char name[20];
	char password[20];
};

/*---------------------结构体------------------------*/
typedef struct BIG_MSG{
	int cmd;
	struct worker_info info;
	struct client cl;
	char data_name[300];
	char data_value[300];
}MSG;

/*-------------------一级选项------------------------*/
typedef enum choise{
	REGISTER = 1,
	LOGIN,
	QUIT,
}f_choise;

/*-------------------二级选项------------------------*/
typedef enum admin_choise{
	FIND_INFO = 1,
	CHANGE_INFO,
	ADD_USER,
	DEL_USER,
	quit,
}s_choise;

/*----------------客户端函数声明---------------------*/
void register_func( MSG* msg, int fd);
void login_func(MSG* msg, int fd);
void add_worker(MSG* msg, int fd);
void find_info(MSG* msg, int fd);
void del_worker(MSG* msg, int fd);
void change_info(MSG* msg, int fd);

/*----------------服务器函数声明---------------------*/
void client_info(const struct sockaddr_in cin);
void client_handle(cli_info* cli);
void database_create(sqlite3* db, cli_info* cli);
void database_insert(sqlite3* db, char* errmsg, MSG* msg);
void database_strcmp(int fd,sqlite3* db, char* errmsg, MSG* msg);
void database_add(int fd, sqlite3* db, char* errmsg, MSG* msg);
void database_find(int fd, sqlite3* db, char* errmsg, MSG* msg);
int callback(void* para, int f_num, char** f_value,char** f_name);
void database_del(int fd, sqlite3* db, char* errmsg,MSG* msg);
void database_change(int fd, sqlite3* db, char* errmsg, MSG* msg);


#endif //HEAD_H__
