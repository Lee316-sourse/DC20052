/*================================================================
 *   Copyright (C) 2020 hqyj Ltd. All rights reserved.
 *   
 *   文件名称：client.c
 *   创 建 者：Lee
 *   创建日期：2020年10月10日
 *   描    述：
 *
 ================================================================*/


#include "head.h"


int main(int argc, char *argv[])
{
	MSG M;
	int cmd_f;
	struct sockaddr_in sin;

	/*-------------------------客户端初始化模块-------------------------*/	
	int fd = socket(AF_INET,SOCK_STREAM,0);
	if(fd == -1){
		perror("socket");
		exit(1);
	}

	//允许地址重用
	int flag = 1;
	setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&flag,sizeof(flag));

	//1 填充服务器地址信息结构体变量
	socklen_t addrlen = sizeof(sin);
	sin.sin_family = AF_INET;
	sin.sin_port   = htons(SERV_PORT);
	if(inet_pton(AF_INET,SERV_IP,&sin.sin_addr.s_addr)<0){
		perror("pton");
		exit(1);
	}

	//2 connect
	if(connect(fd,(struct sockaddr*)&sin,addrlen)<0){
		perror("connect");
		exit(1);
	}

	/*-----------------------客户端选择判断模块-----------------------*/	
	while(1){
		puts("**********************************");
		puts("1 注册        2 登录        3 退出");
		puts("**********************************");
		printf("please input choise >");
		scanf("%d",&cmd_f);

		switch(cmd_f){
		case REGISTER:
			register_func(&M,fd);
			break;
		case LOGIN:
			login_func(&M,fd);
			break;
		case QUIT:
			puts("您已退出！");
			exit(1);
		default:
			puts("输入有误，请重试!");
			break;
		}
	}
	return 0;
}

/*-------------------------客户端注册模块--------------------------*/	
void register_func(MSG* msg, int fd)
{
	int ret = -1;
	printf("请输入 用户名\n");
	scanf("%s",msg->cl.name);
	printf("请输入 密码\n");
	scanf("%s",msg->cl.password);
	msg->cmd = 1;
	do{
	ret = send(fd,msg,sizeof(MSG),0);
	}while(ret<0 && EINTR==errno);
	if(ret <0){
		perror("send");
		exit(1);
	}else if(0 == ret){
		puts("服务器断开\n");
		exit(1);
	}else{
		puts("注册成功");
	}
}

/*-------------------------客户端登录模块-------------------------*/	
void login_func(MSG* msg,int fd)
{
	int cmd_f = -1;
	int ret = -1;
TRY:	
//	bzero(msg,sizeof(MSG));
	printf("用户名:");
	scanf("%s",msg->cl.name);
	printf("密码:");
	scanf("%s",msg->cl.password);

	if(0==(strcmp(msg->cl.name,ADMIN_NAME)))
	{	if(0 == strcmp(msg->cl.password,ADMIN_PASSWORD))
		{
			//输入信息匹配管理员信息，进入管理员模块
			puts("欢迎李睿骁前来视察");
			while(1){
				puts("******************************************************");
				puts("1 查询信息  2 修改信息  3 添加人员  4 删除人员  5 退出");
				puts("******************************************************");
				printf("please input admin choise >");
				scanf("%d",&cmd_f);
				switch(cmd_f){
				case FIND_INFO:
					find_info(msg,fd);
					break;
				case CHANGE_INFO:
					change_info(msg,fd);
					break;
				case ADD_USER:
					add_worker(msg,fd);
					break;
				case DEL_USER:
					del_worker(msg,fd);
					break;
				case quit:
					puts("您已退出！");
					exit(1);
				default:
					puts("输入有误，请重试!");
					break;
				}
			}
		}

	}
	//普通用户模块
	msg->cmd = 2;
	do{
		ret = send(fd,msg,sizeof(MSG),0);
	}while(ret<0 && EINTR==errno);
	if(ret <0){
		perror("send");
		exit(1);
	}else if(0 == ret){
		puts("服务器断开");
		exit(1);
	}
	bzero(msg,sizeof(MSG));
	do{
		ret = recv(fd,msg,sizeof(MSG),0);
	}while(ret<0 && EINTR==errno);

	if(ret <0){
		perror("recv");
		exit(1);
	}else if(0 == ret){
		puts("服务器退出");
		exit(1);
	}else{
		if(0 == strcmp(msg->cl.result,"OK")){
			puts("登录成功");
			printf("尊敬的%s，欢迎您!\n",msg->cl.name);
			while(1){
				puts("******************");
				puts("1 查询	  2 退出");
				puts("******************");
				printf("please input admin choise >");
				scanf("%d",&cmd_f);

				switch(cmd_f){
				case FIND_INFO:
					find_info(msg,fd);
					break;
				case 2:
					puts("您已退出");
					exit(1);
					break;
				default:
					puts("输入有误，请重试!");
					break;
				}
			}
		}	
	}

	if(0 == strcmp(msg->cl.result,"usr/password wrong")){
		puts("用户名或者密码错误，请重试");
		goto TRY;
	}

}

/*--------------------客户端添加人员模块---------------------*/	
void add_worker(MSG* msg, int fd)
{
	bzero(msg,sizeof(MSG));
	int ret = -1;
	msg->cmd = 3;	

	printf("部门: ");
	fflush(stdout);
	scanf("%s",msg->info.part);
	while(getchar()!='\n');
	printf("姓名: ");
	fflush(stdout);
	scanf("%s",msg->info.name);
	while(getchar()!='\n');
	printf("员工号: ");
	fflush(stdout);
	scanf("%s",msg->info.numb);
	while(getchar()!='\n');
	printf("性别: ");
	fflush(stdout);
	scanf("%s",msg->info.sex);
	while(getchar()!='\n');
	printf("年龄: ");
	fflush(stdout);
	scanf("%d",&msg->info.age);
	while(getchar()!='\n');
	printf("薪资: ");
	fflush(stdout);
	scanf("%f",&msg->info.salary);
	while(getchar()!='\n');
	printf("电话: ");
	fflush(stdout);
	scanf("%s",msg->info.tele);
	while(getchar()!='\n');
	printf("住址: ");
	fflush(stdout);
	scanf("%s",msg->info.addr);
	while(getchar()!='\n');

	do{
		ret = send(fd,msg,sizeof(MSG),0);
	}while(ret<0 && EINTR==errno);
	if(ret <0){
		perror("add_user_send");
		exit(1);
	}else if(0 == ret){
		puts("服务器关闭");
		exit(1);
	}else{
		bzero(msg,sizeof(MSG));
		do{
			ret = recv(fd,msg,sizeof(MSG),0);
		}while(ret<0 && EINTR==errno);
		if(ret <0){
			perror("add_user_recv");
			exit(1);
		}else if(0 == ret){
			puts("服务器关闭");
			exit(1);
		}else{
			if(strcmp(msg->info.result,"OK")==0){
				puts("添加人员成功");
			}
		}
	}

}

/*--------------------客户端查询人员信息模块---------------------*/	
void find_info(MSG*msg, int fd)
{
	int ret = -1;
	msg->cmd = 4;
	puts("请输入姓名+ 员工号");
	scanf("%s%s",msg->info.name,msg->info.numb);
	do{
		ret = send(fd,msg,sizeof(MSG),0);
	}while(ret<0 && EINTR==errno);
	if(ret <0){
		perror("find_info_send");
		exit(1);
	}else if(0 == ret){
		puts("服务器关闭");
		exit(1);
	}else{
		bzero(msg,sizeof(MSG));
		do{
			ret = recv(fd,msg,sizeof(MSG),0);
		}while(ret <0 && errno==EINTR);
		if(ret <0){
			perror("find_info_recv");
			exit(1);
		}else if(ret ==0){
			puts("服务器关闭");
		}else{
			if(strcmp(msg->info.result,"find_error")==0){
			puts("查询数据不存在");
			}else{
				puts("查询成功");
				printf("%s\n",msg->data_name);
				printf("%s\n",msg->data_value);
	
			}
		}
	}
}

/*--------------------客户端删除人员信息模块---------------------*/	
void del_worker(MSG* msg, int fd)
{
//	bzero(&msg->info,sizeof(msg->info));
	int ret = -1;
	msg->cmd = 5;
	puts("请输入姓名+ 员工号");
	scanf("%s%s",msg->info.name,msg->info.numb);
	do{
		ret = send(fd,msg,sizeof(MSG),0);
	}while(ret<0 && EINTR==errno);
	if(ret <0){
		perror("find_info_send");
		exit(1);
	}else if(0 == ret){
		puts("服务器关闭");
		exit(1);
	}else{
		bzero(msg,sizeof(MSG));
		do{	
			ret = recv(fd,msg,sizeof(MSG),0);
		}while(ret<0 && EINTR==errno);
		if(ret <0){
			perror("del_worker_recv");
			exit(1);
		}else if(0 == ret){
			puts("服务器关闭");
		}else{
			if(strcmp(msg->info.result,"OK")==0){
				puts("删除完成");
			}else{
				puts("删除信息不存在,请重试");
			}
		}
	}
}

/*--------------------客户端修改人员信息模块---------------------*/	
void change_info(MSG* msg, int fd)
{
	int ret = -1;
	char cmd_f;
	msg->cmd = 6;
	bzero(buf_name,sizeof(buf_name));
	bzero(buf_numb,sizeof(buf_numb));
	puts("输入要修改的人员 格式(姓名+员工号)");
	scanf("%s%s",buf_name,buf_numb);
	
	
	
	while(1){
		puts("********请输入修改的内容********");
		puts("1 部门  2 姓名  3 员工号  4 性别");
		puts("5 年龄  6 薪水  7 电话    8 住址");
		scanf("%d",&msg->info.cmd_info);
		strcpy(msg->info.name,buf_name);
		strcpy(msg->info.numb,buf_numb);
	
			
		switch(msg->info.cmd_info){
			case 1:
				printf("修改Part: ");
				scanf("%s",msg->info.part);
				break;
			case 2:
				printf("修改Name: ");
				scanf("%s",msg->info.name);
				break;
			case 3:
				printf("修改Numb: ");
				scanf("%s",msg->info.numb);
				break;
			case 4:
				printf("修改Sex: ");
				scanf("%s",msg->info.sex);
				break;
			case 5:
				printf("修改Age: ");
				scanf("%d",&msg->info.age);
				break;
			case 6:
				printf("修改Salary: ");
				scanf("%f",&msg->info.salary);
				break;
			case 7:
				printf("修改Tele: ");
				scanf("%s",msg->info.tele);
				break;
			case 8:
				printf("修改Addr: ");
				scanf("%s",msg->info.addr);
				break;
			default:
				puts("输入不合法，请重试");
				break;
		}

		do{
			ret = send(fd,msg,sizeof(MSG),0);
		}while(ret<0 && EINTR==errno);
		if(ret <0){
			perror("find_info_send");
			exit(1);
		}else if(0 == ret){
			puts("服务器关闭");
			exit(1);
		}else{
			bzero(msg,sizeof(MSG));
			do{
				ret = recv(fd,msg,sizeof(MSG),0);
			}while(ret<0 && EINTR==errno);
			if(ret <0){
				perror("change_info_send");
				exit(1);
			}else if(0 == ret){
				puts("服务器关闭");
			}else{
				if(strcmp(msg->info.result,"change_ok")== 0){
NEXT:				puts("修改信息完成，是否继续修改(Y/N)?");
					scanf("%s",&cmd_f);
					if(strncasecmp(&cmd_f,"y",1)==0){
						continue;
					}else if(strncasecmp(&cmd_f,"n",1)==0){
						break;
					}else{
						puts("输入有误，请重试");
						goto NEXT;
					}

				}else if(strcmp(msg->info.result,"change_error")==0){
					puts("输入的人员不存在");
					break;
				}
			}
		}

	}

}

